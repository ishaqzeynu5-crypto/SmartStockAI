package com.example.smartstock.ai

import com.example.smartstock.data.Item
import org.json.JSONArray
import org.json.JSONObject

object GeminiPrompts {

    private const val MAX_CATALOGUE_ITEMS = 300

    fun buildCatalogueJson(items: List<Item>): String {
        val arr = JSONArray()
        items.take(MAX_CATALOGUE_ITEMS).forEach { item ->
            val obj = JSONObject()
            obj.put("id", item.id)
            obj.put("name", item.name)
            obj.put("unit", item.unit)
            if (item.aliases.isNotEmpty()) {
                val aliases = JSONArray()
                item.aliases.forEach { aliases.put(it) }
                obj.put("aliases", aliases)
            }
            arr.put(obj)
        }
        return arr.toString()
    }

    fun cargoSystemInstruction(isEnglish: Boolean = false): String = """
        You are a meticulous inventory auditor for an Ethiopian shop.
        COUNTING & COMPARISON RULES (FOLLOW STRICTLY):
        1. Count ONLY clearly visible units. NEVER guess hidden or stacked units; if items look stacked or partially obstructed, mention it explicitly in report_am and mark confidence "low".
        2. When TWO photos are provided (Photo 1 = SENT cargo, Photo 2 = RECEIVED cargo):
           - First identify every distinct product in Photo 1 using a specific, clear name (include color, size, or packaging type so similar items are not confused).
           - Then inspect Photo 2 carefully side-by-side against Photo 1 and count how many of EACH exact product arrived.
           - CRITICAL: For the SAME physical product appearing in both photos, you MUST use the EXACT SAME character-for-character "name" string in both sent_items and received_items! Never rename or reword the same item between sent_items and received_items.
           - If an item from Photo 1 is completely missing in Photo 2, include it in sent_items with its sent qty, and either omit it from received_items or include it with qty 0 using the exact same name.
           - Only introduce a new item name in received_items if that product genuinely did not appear in Photo 1.
        3. If ONLY ONE photo (received cargo) is provided, sent_items MUST be an empty array [].
        4. Match received items against the shop catalogue JSON (id, name, aliases, unit) and put the exact matching id in matched_stock_id, or null if unmatched.
        5. Set confidence to "high", "medium", or "low". Mark blurry, crowded, or uncertain counts as "low".
        6. In report_am, clearly list every missing item (sent > received) and extra item (received > sent), plus any visibility limitations.
        7. ${if (isEnglish) "ALL free text (report_am, photo_note_am, and item names) MUST be written in clear, natural English." else "ALL free text (report_am, photo_note_am, and item names when not a brand name) MUST be written in natural Amharic (አማርኛ)."}
        Return strictly valid JSON matching the requested schema.
    """.trimIndent()

    fun cargoUserPrompt(items: List<Item>, hasSentPhoto: Boolean): String {
        val catalogue = buildCatalogueJson(items)
        val photoDesc = if (hasSentPhoto) {
            "Photo 1 is the SENT cargo. Photo 2 is the RECEIVED cargo."
        } else {
            "Only the RECEIVED cargo photo is provided (count mode; return sent_items as [])."
        }
        return "$photoDesc\nShop catalogue JSON:\n$catalogue"
    }

    fun cargoResponseSchema(): JSONObject {
        val sentItemProps = JSONObject()
            .put("name", JSONObject().put("type", "STRING"))
            .put("qty", JSONObject().put("type", "INTEGER"))
            .put("confidence", JSONObject().put("type", "STRING").put("enum", JSONArray(listOf("high", "medium", "low"))))

        val receivedItemProps = JSONObject()
            .put("name", JSONObject().put("type", "STRING"))
            .put("matched_stock_id", JSONObject().put("type", "STRING").put("nullable", true))
            .put("qty", JSONObject().put("type", "INTEGER"))
            .put("confidence", JSONObject().put("type", "STRING").put("enum", JSONArray(listOf("high", "medium", "low"))))

        return JSONObject()
            .put("type", "OBJECT")
            .put(
                "properties",
                JSONObject()
                    .put(
                        "sent_items",
                        JSONObject()
                            .put("type", "ARRAY")
                            .put(
                                "items",
                                JSONObject()
                                    .put("type", "OBJECT")
                                    .put("properties", sentItemProps)
                                    .put("required", JSONArray(listOf("name", "qty", "confidence")))
                            )
                    )
                    .put(
                        "received_items",
                        JSONObject()
                            .put("type", "ARRAY")
                            .put(
                                "items",
                                JSONObject()
                                    .put("type", "OBJECT")
                                    .put("properties", receivedItemProps)
                                    .put("required", JSONArray(listOf("name", "qty", "confidence")))
                            )
                    )
                    .put("report_am", JSONObject().put("type", "STRING"))
                    .put("photo_note_am", JSONObject().put("type", "STRING"))
            )
            .put("required", JSONArray(listOf("sent_items", "received_items", "report_am", "photo_note_am")))
    }

    fun salesSystemInstruction(isEnglish: Boolean = false): String = """
        You are reading handwritten sales-notebook pages from a small Ethiopian shop.
        Handwriting mixes Amharic (አማርኛ), English, and Ge'ez numerals (፩–፱, ፲, etc.).
        CRITICAL PARSING RULES:
        - In expressions like "2 x 1550 = 3100", qty is 2, unit_price is 1550, and line_total is 3100.
        - qty is ALWAYS the count sold, NEVER the price.
        - If the order of quantity and price is ambiguous, use the written line_total to decide which number is qty and which is unit_price.
        - Ignore struck-through/crossed-out lines, dates, customer names, phone numbers, and page headings.
        - NEVER invent items that are not written on the page.
        - Mark any doubtful, smudged, or hard-to-read line with confidence "low".
        - Match each item to the provided shop catalogue JSON (id, name, aliases, unit) and return its exact id in matched_stock_id, or null if not matched.
        - If a grand total is written at the bottom of the page, extract it as written_grand_total (otherwise null).
        - ${if (isEnglish) "Write notes_am in clear, natural English." else "Write notes_am in natural Amharic."}
        Return strictly valid JSON matching the requested schema.
    """.trimIndent()

    fun salesUserPrompt(items: List<Item>, photoCount: Int): String {
        val catalogue = buildCatalogueJson(items)
        return "Read all $photoCount handwritten sales-notebook page photo(s) and extract every valid sales line.\nShop catalogue JSON:\n$catalogue"
    }

    fun salesResponseSchema(): JSONObject {
        val lineProps = JSONObject()
            .put("raw_text", JSONObject().put("type", "STRING"))
            .put("name", JSONObject().put("type", "STRING"))
            .put("matched_stock_id", JSONObject().put("type", "STRING").put("nullable", true))
            .put("qty", JSONObject().put("type", "INTEGER"))
            .put("unit_price", JSONObject().put("type", "NUMBER").put("nullable", true))
            .put("line_total", JSONObject().put("type", "NUMBER").put("nullable", true))
            .put("confidence", JSONObject().put("type", "STRING").put("enum", JSONArray(listOf("high", "medium", "low"))))

        return JSONObject()
            .put("type", "OBJECT")
            .put(
                "properties",
                JSONObject()
                    .put(
                        "lines",
                        JSONObject()
                            .put("type", "ARRAY")
                            .put(
                                "items",
                                JSONObject()
                                    .put("type", "OBJECT")
                                    .put("properties", lineProps)
                                    .put("required", JSONArray(listOf("raw_text", "name", "qty", "confidence")))
                            )
                    )
                    .put("written_grand_total", JSONObject().put("type", "NUMBER").put("nullable", true))
                    .put("notes_am", JSONObject().put("type", "STRING"))
            )
            .put("required", JSONArray(listOf("lines", "notes_am")))
    }

    fun weeklyAdviceSystemInstruction(isEnglish: Boolean = false): String = """
        You are a practical business advisor for a small Ethiopian shop owner.
        Based ONLY on the compact 14-day sales, stock, and days-of-cover summary provided, give 3 to 5 short, actionable suggestions in ${if (isEnglish) "clear, natural English" else "natural Amharic (አማርኛ)"}.
        Focus on: items to reorder soon (low days of cover), slow movers, and any sales or stock anomalies.
        Keep each suggestion concise (1–2 sentences). Return strictly valid JSON matching the schema.
    """.trimIndent()

    fun weeklyAdviceResponseSchema(): JSONObject {
        return JSONObject()
            .put("type", "OBJECT")
            .put(
                "properties",
                JSONObject().put(
                    "suggestions",
                    JSONObject()
                        .put("type", "ARRAY")
                        .put("items", JSONObject().put("type", "STRING"))
                )
            )
            .put("required", JSONArray(listOf("suggestions")))
    }
}
