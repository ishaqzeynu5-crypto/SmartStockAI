package com.example.smartstock.domain

import com.example.smartstock.data.CreditPayment
import com.example.smartstock.data.CustomerCredit
import com.example.smartstock.data.Item
import com.example.smartstock.data.Txn
import com.example.smartstock.data.TxnStatus
import com.example.smartstock.data.TxnType
import com.example.smartstock.util.EthiopianCalendar
import com.example.smartstock.util.NameNormalizer
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId

enum class ReportPeriod {
    DAYS_7,
    DAYS_30,
    ALL_TIME
}

data class SalesProfitPoint(
    val label: String,
    val salesEtb: Double,
    val profitEtb: Double
)

data class ItemReportRow(
    val name: String,
    val qtySold: Int,
    val revenueEtb: Double,
    val estimatedProfitEtb: Double?
)

data class PeriodReport(
    val totalRevenueEtb: Double,
    val totalEstimatedProfitEtb: Double?,
    val profitMarginPercent: Double?,
    val saleCount: Int,
    val averageSaleEtb: Double,
    val chartPoints: List<SalesProfitPoint>,
    val topItems: List<ItemReportRow>
)

object CreditAndReportEngine {

    fun recordCreditPayment(
        credits: List<CustomerCredit>,
        creditId: String,
        amountEtb: Double,
        note: String? = null
    ): List<CustomerCredit> {
        if (amountEtb <= 0.0) return credits
        return credits.map { credit ->
            if (credit.id != creditId) {
                credit
            } else {
                val applied = amountEtb.coerceAtMost(credit.remainingEtb)
                if (applied <= 0.0) {
                    credit
                } else {
                    val payment = CreditPayment(amountEtb = applied, note = note?.trim()?.takeIf { it.isNotEmpty() })
                    credit.copy(
                        paidEtb = credit.paidEtb + applied,
                        payments = listOf(payment) + credit.payments
                    )
                }
            }
        }
    }

    fun totalOutstandingCredit(credits: List<CustomerCredit>): Double {
        return credits.sumOf { it.remainingEtb }
    }

    fun computePeriodReport(
        items: List<Item>,
        history: List<Txn>,
        period: ReportPeriod,
        today: LocalDate = LocalDate.now(),
        zoneId: ZoneId = ZoneId.systemDefault()
    ): PeriodReport {
        val itemById = items.associateBy { it.id }
        val activeSales = history.filter { it.status == TxnStatus.ACTIVE && it.type == TxnType.SALE }

        val startDate: LocalDate? = when (period) {
            ReportPeriod.DAYS_7 -> today.minusDays(6)
            ReportPeriod.DAYS_30 -> today.minusDays(29)
            ReportPeriod.ALL_TIME -> null
        }

        val scopedSales = activeSales.filter { txn ->
            if (startDate == null) {
                true
            } else {
                val d = Instant.ofEpochMilli(txn.timestamp).atZone(zoneId).toLocalDate()
                !d.isBefore(startDate) && !d.isAfter(today)
            }
        }

        val totalRevenue = scopedSales.sumOf { it.totalEtb }
        val saleCount = scopedSales.size
        val averageSale = if (saleCount > 0) totalRevenue / saleCount else 0.0

        var profitTotal = 0.0
        var hasAnyCost = false

        class ItemAcc(
            val name: String,
            var qty: Int = 0,
            var revenue: Double = 0.0,
            var profit: Double = 0.0,
            var hasCost: Boolean = false
        )

        val itemMap = LinkedHashMap<String, ItemAcc>()
        val salesByDay = mutableMapOf<LocalDate, Double>()
        val profitByDay = mutableMapOf<LocalDate, Double>()

        for (txn in scopedSales) {
            val d = Instant.ofEpochMilli(txn.timestamp).atZone(zoneId).toLocalDate()
            salesByDay[d] = (salesByDay[d] ?: 0.0) + txn.totalEtb

            for (line in txn.lines) {
                val item = line.itemId?.let { itemById[it] }
                val key = line.itemId ?: NameNormalizer.normalize(line.name)
                val acc = itemMap.getOrPut(key) { ItemAcc(line.name) }
                val unitPrice = line.unitPrice ?: item?.sellPrice ?: 0.0
                val lineRev = line.qty * unitPrice
                acc.qty += line.qty
                acc.revenue += lineRev

                val cost = item?.costPrice
                if (cost != null) {
                    val lineProfit = (unitPrice - cost) * line.qty
                    acc.profit += lineProfit
                    acc.hasCost = true
                    profitTotal += lineProfit
                    hasAnyCost = true
                    profitByDay[d] = (profitByDay[d] ?: 0.0) + lineProfit
                }
            }
        }

        val estimatedProfit = if (hasAnyCost) profitTotal else null
        val marginPercent = if (estimatedProfit != null && totalRevenue > 0.0) {
            (estimatedProfit / totalRevenue) * 100.0
        } else {
            null
        }

        val chartPoints: List<SalesProfitPoint> = when (period) {
            ReportPeriod.DAYS_7 -> (6 downTo 0).map { offset ->
                val d = today.minusDays(offset.toLong())
                SalesProfitPoint(
                    label = EthiopianCalendar.weekdayShort(d),
                    salesEtb = salesByDay[d] ?: 0.0,
                    profitEtb = (profitByDay[d] ?: 0.0).coerceAtLeast(0.0)
                )
            }
            ReportPeriod.DAYS_30 -> {
                // 6 buckets of 5 days each
                (5 downTo 0).map { bucket ->
                    val bucketEnd = today.minusDays((bucket * 5).toLong())
                    val bucketStart = bucketEnd.minusDays(4)
                    var s = 0.0
                    var p = 0.0
                    var cur = bucketStart
                    while (!cur.isAfter(bucketEnd)) {
                        s += salesByDay[cur] ?: 0.0
                        p += profitByDay[cur] ?: 0.0
                        cur = cur.plusDays(1)
                    }
                    SalesProfitPoint(
                        label = "${bucketStart.dayOfMonth}/${bucketStart.monthValue}",
                        salesEtb = s,
                        profitEtb = p.coerceAtLeast(0.0)
                    )
                }
            }
            ReportPeriod.ALL_TIME -> {
                val sortedDays = salesByDay.keys.sorted()
                sortedDays.takeLast(7).map { d ->
                    SalesProfitPoint(
                        label = "${d.dayOfMonth}/${d.monthValue}",
                        salesEtb = salesByDay[d] ?: 0.0,
                        profitEtb = (profitByDay[d] ?: 0.0).coerceAtLeast(0.0)
                    )
                }
            }
        }

        val topItems = itemMap.values
            .sortedByDescending { it.revenue }
            .take(5)
            .map {
                ItemReportRow(
                    name = it.name,
                    qtySold = it.qty,
                    revenueEtb = it.revenue,
                    estimatedProfitEtb = if (it.hasCost) it.profit else null
                )
            }

        return PeriodReport(
            totalRevenueEtb = totalRevenue,
            totalEstimatedProfitEtb = estimatedProfit,
            profitMarginPercent = marginPercent,
            saleCount = saleCount,
            averageSaleEtb = averageSale,
            chartPoints = chartPoints,
            topItems = topItems
        )
    }
}
