package com.example.smartstock.ui.screens

import android.content.Intent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.smartstock.R
import com.example.smartstock.data.CustomerCredit
import com.example.smartstock.data.DateStyle
import com.example.smartstock.domain.CreditAndReportEngine
import com.example.smartstock.ui.AppUiState
import com.example.smartstock.ui.components.EmptyStateCard
import com.example.smartstock.ui.components.StatusBadge
import com.example.smartstock.ui.theme.MatchGreen
import com.example.smartstock.ui.theme.ShortageRed
import com.example.smartstock.util.EthiopianCalendar
import com.example.smartstock.util.Formatters

@Composable
fun CreditScreen(
    state: AppUiState,
    onAddCredit: (customerName: String, phone: String?, amountEtb: Double, note: String?) -> Unit,
    onRecordPayment: (creditId: String, amountEtb: Double, note: String?) -> Unit,
    onDeleteCredit: (creditId: String) -> Unit
) {
    val context = LocalContext.current
    var showPaidOff by rememberSaveable { mutableStateOf(false) }
    var showAddDialog by remember { mutableStateOf(false) }
    var payingCredit by remember { mutableStateOf<CustomerCredit?>(null) }
    var deletingCredit by remember { mutableStateOf<CustomerCredit?>(null) }

    val totalOutstanding = CreditAndReportEngine.totalOutstandingCredit(state.credits)
    val activeCount = state.credits.count { !it.isPaidOff }
    val useEth = state.settings.dateStyle == DateStyle.ETHIOPIAN

    val filtered = remember(state.credits, showPaidOff) {
        state.credits.filter { if (showPaidOff) it.isPaidOff else !it.isPaidOff }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item(key = "credit_summary") {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(
                        text = stringResource(R.string.credit_summary_total, Formatters.formatMoney(totalOutstanding)),
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                    Text(
                        text = stringResource(R.string.credit_summary_count, activeCount),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                }
            }
        }

        item(key = "credit_controls") {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(
                        selected = !showPaidOff,
                        onClick = { showPaidOff = false },
                        label = { Text(stringResource(R.string.credit_filter_active)) }
                    )
                    FilterChip(
                        selected = showPaidOff,
                        onClick = { showPaidOff = true },
                        label = { Text(stringResource(R.string.credit_filter_paid)) }
                    )
                }
                Button(
                    onClick = { showAddDialog = true },
                    modifier = Modifier.heightIn(min = 48.dp)
                ) {
                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(stringResource(R.string.credit_btn_add))
                }
            }
        }

        if (filtered.isEmpty()) {
            item(key = "credit_empty") {
                EmptyStateCard(
                    title = stringResource(R.string.credit_empty_title),
                    body = stringResource(R.string.credit_empty_body),
                    ctaLabel = if (!showPaidOff) stringResource(R.string.credit_btn_add) else null,
                    onCtaClick = if (!showPaidOff) { { showAddDialog = true } } else null
                )
            }
        } else {
            items(filtered, key = { it.id }) { credit ->
                CreditCard(
                    credit = credit,
                    useEthiopianDate = useEth,
                    onRecordPayment = { payingCredit = credit },
                    onShareReminder = {
                        val msg = context.getString(
                            R.string.credit_reminder_text,
                            credit.customerName,
                            Formatters.formatMoney(credit.remainingEtb)
                        )
                        val intent = Intent(Intent.ACTION_SEND).apply {
                            type = "text/plain"
                            putExtra(Intent.EXTRA_TEXT, msg)
                        }
                        context.startActivity(Intent.createChooser(intent, context.getString(R.string.credit_btn_share_reminder)))
                    },
                    onDelete = { deletingCredit = credit }
                )
            }
        }
    }

    if (showAddDialog) {
        AddCreditDialog(
            onDismiss = { showAddDialog = false },
            onSave = { name, phone, amount, note ->
                onAddCredit(name, phone, amount, note)
                showAddDialog = false
            }
        )
    }

    payingCredit?.let { target ->
        RecordPaymentDialog(
            credit = target,
            onDismiss = { payingCredit = null },
            onSave = { amount, note ->
                onRecordPayment(target.id, amount, note)
                payingCredit = null
            }
        )
    }

    deletingCredit?.let { target ->
        AlertDialog(
            onDismissRequest = { deletingCredit = null },
            title = { Text(stringResource(R.string.credit_delete_title)) },
            text = { Text(stringResource(R.string.credit_delete_body, target.customerName)) },
            confirmButton = {
                Button(onClick = {
                    onDeleteCredit(target.id)
                    deletingCredit = null
                }) {
                    Text(stringResource(R.string.action_delete))
                }
            },
            dismissButton = {
                TextButton(onClick = { deletingCredit = null }) {
                    Text(stringResource(R.string.action_cancel))
                }
            }
        )
    }
}

@Composable
private fun CreditCard(
    credit: CustomerCredit,
    useEthiopianDate: Boolean,
    onRecordPayment: () -> Unit,
    onShareReminder: () -> Unit,
    onDelete: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            text = credit.customerName,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        if (credit.isPaidOff) {
                            StatusBadge(
                                text = stringResource(R.string.credit_badge_paid_off),
                                backgroundColor = MatchGreen.copy(alpha = 0.15f),
                                contentColor = MatchGreen
                            )
                        }
                    }
                    credit.phone?.let {
                        Text(
                            text = it,
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
                IconButton(onClick = onDelete, modifier = Modifier.size(48.dp)) {
                    Icon(
                        Icons.Default.Delete,
                        contentDescription = stringResource(R.string.action_delete),
                        tint = MaterialTheme.colorScheme.error
                    )
                }
            }

            Text(
                text = stringResource(R.string.credit_remaining_label, Formatters.formatMoney(credit.remainingEtb)),
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = if (credit.isPaidOff) MatchGreen else ShortageRed
            )
            Text(
                text = stringResource(
                    R.string.credit_paid_label,
                    Formatters.formatMoney(credit.paidEtb),
                    Formatters.formatMoney(credit.totalOwedEtb)
                ),
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            credit.note?.let {
                Text(text = it, style = MaterialTheme.typography.bodyMedium)
            }

            if (credit.payments.isNotEmpty()) {
                Spacer(modifier = Modifier.height(2.dp))
                credit.payments.take(3).forEach { pay ->
                    val d = EthiopianCalendar.formatTimestampDate(pay.timestamp, useEthiopianDate)
                    Text(
                        text = "• $d — ${stringResource(R.string.money_format, Formatters.formatMoney(pay.amountEtb))}",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            if (!credit.isPaidOff) {
                Spacer(modifier = Modifier.height(4.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = onRecordPayment,
                        modifier = Modifier
                            .weight(1f)
                            .heightIn(min = 48.dp)
                    ) {
                        Text(stringResource(R.string.credit_btn_record_payment))
                    }
                    OutlinedButton(
                        onClick = onShareReminder,
                        modifier = Modifier.heightIn(min = 48.dp)
                    ) {
                        Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(stringResource(R.string.credit_btn_share_reminder))
                    }
                }
            }
        }
    }
}

@Composable
private fun AddCreditDialog(
    onDismiss: () -> Unit,
    onSave: (String, String?, Double, String?) -> Unit
) {
    var customer by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var amountText by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }
    var showError by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(stringResource(R.string.credit_dialog_add_title)) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = customer,
                    onValueChange = { customer = it; showError = false },
                    label = { Text(stringResource(R.string.credit_field_customer)) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = phone,
                    onValueChange = { phone = it },
                    label = { Text(stringResource(R.string.credit_field_phone)) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = amountText,
                    onValueChange = { amountText = it; showError = false },
                    label = { Text(stringResource(R.string.credit_field_amount)) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = note,
                    onValueChange = { note = it },
                    label = { Text(stringResource(R.string.credit_field_note)) },
                    singleLine = false,
                    modifier = Modifier.fillMaxWidth()
                )
                if (showError) {
                    Text(
                        text = stringResource(R.string.credit_err_invalid),
                        color = MaterialTheme.colorScheme.error,
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
            }
        },
        confirmButton = {
            Button(onClick = {
                val amt = amountText.trim().toDoubleOrNull()
                if (customer.isBlank() || amt == null || amt <= 0.0) {
                    showError = true
                } else {
                    onSave(
                        customer.trim(),
                        phone.trim().takeIf { it.isNotEmpty() },
                        amt,
                        note.trim().takeIf { it.isNotEmpty() }
                    )
                }
            }) {
                Text(stringResource(R.string.action_save))
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text(stringResource(R.string.action_cancel))
            }
        }
    )
}

@Composable
private fun RecordPaymentDialog(
    credit: CustomerCredit,
    onDismiss: () -> Unit,
    onSave: (Double, String?) -> Unit
) {
    var amountText by remember { mutableStateOf(credit.remainingEtb.toLong().toString()) }
    var note by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(stringResource(R.string.credit_payment_dialog_title, credit.customerName)) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = amountText,
                    onValueChange = { amountText = it },
                    label = { Text(stringResource(R.string.credit_payment_amount)) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = note,
                    onValueChange = { note = it },
                    label = { Text(stringResource(R.string.credit_field_note)) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(onClick = {
                val amt = amountText.trim().toDoubleOrNull()
                if (amt != null && amt > 0.0) {
                    onSave(amt, note.trim().takeIf { it.isNotEmpty() })
                }
            }) {
                Text(stringResource(R.string.action_save))
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text(stringResource(R.string.action_cancel))
            }
        }
    )
}
