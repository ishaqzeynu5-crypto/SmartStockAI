package com.example.smartstock.ui.screens

import android.content.Intent
import androidx.activity.compose.rememberLauncherForActivityResult
import com.journeyapps.barcodescanner.ScanContract
import com.journeyapps.barcodescanner.ScanOptions
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.smartstock.R
import com.example.smartstock.data.Item
import com.example.smartstock.ui.AppUiState
import com.example.smartstock.ui.components.EmptyStateCard
import com.example.smartstock.ui.components.StatusBadge
import com.example.smartstock.ui.theme.LowStockTintDark
import com.example.smartstock.ui.theme.LowStockTintLight
import com.example.smartstock.ui.theme.ShortageRed
import com.example.smartstock.util.Formatters
import com.example.smartstock.util.NameNormalizer

private enum class StockSort {
    NAME,
    LOWEST
}

@Composable
fun StockScreen(
    state: AppUiState,
    onToggleLowFilter: (Boolean) -> Unit,
    onFindDuplicate: (String, String?) -> Item?,
    onFindByBarcode: (String) -> Item?,
    onAddItem: (name: String, qty: Int, unit: String, sellPrice: Double?, costPrice: Double?, barcode: String?) -> Unit,
    onMergeQty: (itemId: String, addQty: Int) -> Unit,
    onUpdateItem: (Item) -> Unit,
    onAdjustQty: (String, Int) -> Unit,
    onDeleteItem: (String) -> Unit,
    onBuildReorderText: () -> String?,
    onShowMessage: (String) -> Unit
) {
    val context = LocalContext.current
    var searchQuery by rememberSaveable { mutableStateOf("") }
    var sortMode by rememberSaveable { mutableStateOf(StockSort.NAME) }
    var showAddDialog by remember { mutableStateOf(false) }
    var scannedBarcodeForAdd by remember { mutableStateOf<String?>(null) }
    var editingItem by remember { mutableStateOf<Item?>(null) }

    val stockBarcodeLauncher = rememberLauncherForActivityResult(ScanContract()) { result ->
        val code = result.contents?.trim()
        if (!code.isNullOrEmpty()) {
            val existing = onFindByBarcode(code)
            if (existing != null) {
                editingItem = existing
            } else {
                scannedBarcodeForAdd = code
                showAddDialog = true
            }
        }
    }
    var deletingItem by remember { mutableStateOf<Item?>(null) }
    var duplicateMergeCandidate by remember { mutableStateOf<Pair<Item, Int>?>(null) }

    val totalUnits = state.items.sumOf { it.qty }
    val knownCostItems = state.items.filter { it.costPrice != null }
    val totalCostValue = knownCostItems.sumOf { (it.costPrice ?: 0.0) * it.qty }

    val filteredItems = remember(state.items, searchQuery, state.stockFilterLowOnly, sortMode) {
        val normQuery = NameNormalizer.normalize(searchQuery)
        state.items
            .filter { item ->
                val matchesFilter = !state.stockFilterLowOnly || item.qty < item.lowThreshold
                val matchesSearch = normQuery.isEmpty() ||
                    NameNormalizer.normalize(item.name).contains(normQuery) ||
                    item.aliases.any { NameNormalizer.normalize(it).contains(normQuery) }
                matchesFilter && matchesSearch
            }
            .let { list ->
                when (sortMode) {
                    StockSort.NAME -> list.sortedBy { it.name.lowercase() }
                    StockSort.LOWEST -> list.sortedWith(compareBy<Item> { it.qty }.thenBy { it.name.lowercase() })
                }
            }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // Summary Card
        item(key = "stock_summary") {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = stringResource(R.string.stock_summary_types, state.items.size),
                            style = MaterialTheme.typography.titleMedium,
                            color = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                        Text(
                            text = stringResource(R.string.stock_summary_units, Formatters.formatInt(totalUnits)),
                            style = MaterialTheme.typography.titleMedium,
                            color = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                    }
                    if (knownCostItems.isNotEmpty()) {
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = stringResource(
                                R.string.stock_summary_value,
                                Formatters.formatMoney(totalCostValue)
                            ),
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                    }
                }
            }
        }

        // Actions Row: Add Item, Barcode Scan & Share Reorder List
        item(key = "stock_actions") {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Button(
                    onClick = { showAddDialog = true },
                    modifier = Modifier
                        .weight(1f)
                        .heightIn(min = 48.dp)
                ) {
                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(stringResource(R.string.stock_btn_add_item))
                }
                OutlinedButton(
                    onClick = {
                        val opts = ScanOptions().apply {
                            setPrompt(context.getString(R.string.barcode_scan_prompt))
                            setBeepEnabled(true)
                            setOrientationLocked(false)
                        }
                        stockBarcodeLauncher.launch(opts)
                    },
                    modifier = Modifier.heightIn(min = 48.dp)
                ) {
                    Text(stringResource(R.string.action_scan_barcode))
                }
            }
            Spacer(modifier = Modifier.height(6.dp))
            Row(modifier = Modifier.fillMaxWidth()) {
                OutlinedButton(
                    onClick = {
                        val text = onBuildReorderText()
                        if (text == null) {
                            onShowMessage(context.getString(R.string.stock_reorder_none))
                        } else {
                            val intent = Intent(Intent.ACTION_SEND).apply {
                                type = "text/plain"
                                putExtra(Intent.EXTRA_TEXT, text)
                            }
                            context.startActivity(Intent.createChooser(intent, context.getString(R.string.stock_btn_share_reorder)))
                        }
                    },
                    modifier = Modifier.heightIn(min = 48.dp)
                ) {
                    Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(stringResource(R.string.stock_btn_share_reorder))
                }
            }
            }
        }

        // Search & Filter/Sort
        item(key = "stock_search_filter") {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                    placeholder = { Text(stringResource(R.string.stock_search_hint)) }
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    FilterChip(
                        selected = state.stockFilterLowOnly,
                        onClick = { onToggleLowFilter(!state.stockFilterLowOnly) },
                        label = { Text(stringResource(R.string.stock_filter_low)) }
                    )
                    FilterChip(
                        selected = sortMode == StockSort.NAME,
                        onClick = { sortMode = StockSort.NAME },
                        label = { Text(stringResource(R.string.stock_sort_name)) }
                    )
                    FilterChip(
                        selected = sortMode == StockSort.LOWEST,
                        onClick = { sortMode = StockSort.LOWEST },
                        label = { Text(stringResource(R.string.stock_sort_lowest)) }
                    )
                }
            }
        }

        // Empty States or Item List
        if (state.items.isEmpty()) {
            item(key = "stock_empty") {
                EmptyStateCard(
                    title = stringResource(R.string.stock_empty_title),
                    body = stringResource(R.string.stock_empty_body),
                    ctaLabel = stringResource(R.string.stock_btn_add_item),
                    onCtaClick = { showAddDialog = true }
                )
            }
        } else if (filteredItems.isEmpty()) {
            item(key = "stock_empty_filtered") {
                EmptyStateCard(
                    title = stringResource(R.string.stock_empty_filtered),
                    body = ""
                )
            }
        } else {
            items(filteredItems, key = { it.id }) { item ->
                StockItemCard(
                    item = item,
                    onAdjust = { delta -> onAdjustQty(item.id, delta) },
                    onEdit = { editingItem = item },
                    onDelete = { deletingItem = item }
                )
            }
        }
    }

    if (showAddDialog) {
        AddOrEditItemDialog(
            initialItem = null,
            initialBarcode = scannedBarcodeForAdd,
            defaultThreshold = state.settings.defaultLowThreshold,
            onDismiss = {
                showAddDialog = false
                scannedBarcodeForAdd = null
            },
            onSaveNew = { name, qty, unit, sell, cost, barcode ->
                val dup = onFindDuplicate(name, null)
                if (dup != null) {
                    showAddDialog = false
                    scannedBarcodeForAdd = null
                    duplicateMergeCandidate = dup to qty
                } else {
                    onAddItem(name, qty, unit, sell, cost, barcode)
                    showAddDialog = false
                    scannedBarcodeForAdd = null
                }
            },
            onSaveEdit = {}
        )
    }

    editingItem?.let { current ->
        AddOrEditItemDialog(
            initialItem = current,
            initialBarcode = current.barcode,
            defaultThreshold = state.settings.defaultLowThreshold,
            onDismiss = { editingItem = null },
            onSaveNew = { _, _, _, _, _, _ -> },
            onSaveEdit = { updated ->
                onUpdateItem(updated)
                editingItem = null
            }
        )
    }

    duplicateMergeCandidate?.let { (existing, addQty) ->
        AlertDialog(
            onDismissRequest = { duplicateMergeCandidate = null },
            title = { Text(stringResource(R.string.stock_duplicate_title)) },
            text = {
                Text(
                    stringResource(
                        R.string.stock_duplicate_body,
                        existing.name,
                        existing.qty,
                        addQty
                    )
                )
            },
            confirmButton = {
                Button(onClick = {
                    onMergeQty(existing.id, addQty)
                    duplicateMergeCandidate = null
                }) {
                    Text(stringResource(R.string.stock_duplicate_merge))
                }
            },
            dismissButton = {
                TextButton(onClick = { duplicateMergeCandidate = null }) {
                    Text(stringResource(R.string.action_cancel))
                }
            }
        )
    }

    deletingItem?.let { target ->
        AlertDialog(
            onDismissRequest = { deletingItem = null },
            title = { Text(stringResource(R.string.stock_delete_title)) },
            text = { Text(stringResource(R.string.stock_delete_body, target.name)) },
            confirmButton = {
                Button(onClick = {
                    onDeleteItem(target.id)
                    deletingItem = null
                }) {
                    Text(stringResource(R.string.action_delete))
                }
            },
            dismissButton = {
                TextButton(onClick = { deletingItem = null }) {
                    Text(stringResource(R.string.action_cancel))
                }
            }
        )
    }
}

@Composable
private fun StockItemCard(
    item: Item,
    onAdjust: (Int) -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit
) {
    val isDark = isSystemInDarkTheme()
    val isLow = item.qty < item.lowThreshold
    val isOut = item.qty == 0
    val cardBg = if (isLow) {
        if (isDark) LowStockTintDark else LowStockTintLight
    } else {
        MaterialTheme.colorScheme.surface
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onEdit),
        colors = CardDefaults.cardColors(containerColor = cardBg),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = item.name,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold
                    )
                    if (isOut) {
                        StatusBadge(
                            text = stringResource(R.string.stock_badge_out),
                            backgroundColor = ShortageRed,
                            contentColor = Color.White
                        )
                    } else if (isLow) {
                        StatusBadge(
                            text = stringResource(R.string.stock_badge_low),
                            backgroundColor = ShortageRed.copy(alpha = 0.16f),
                            contentColor = ShortageRed
                        )
                    }
                }
                Spacer(modifier = Modifier.height(4.dp))
                val dash = stringResource(R.string.stock_price_dash)
                val sellStr = item.sellPrice?.let { stringResource(R.string.money_format, Formatters.formatMoney(it)) } ?: dash
                val costStr = item.costPrice?.let { stringResource(R.string.money_format, Formatters.formatMoney(it)) } ?: dash
                Text(
                    text = stringResource(R.string.stock_item_sell_cost, sellStr, costStr),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                OutlinedButton(
                    onClick = { onAdjust(-1) },
                    enabled = item.qty > 0,
                    contentPadding = PaddingValues(0.dp),
                    modifier = Modifier.size(48.dp)
                ) {
                    Text("−", style = MaterialTheme.typography.titleLarge)
                }
                Column(
                    modifier = Modifier.padding(horizontal = 10.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = Formatters.formatInt(item.qty),
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = item.unit,
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                OutlinedButton(
                    onClick = { onAdjust(1) },
                    contentPadding = PaddingValues(0.dp),
                    modifier = Modifier.size(48.dp)
                ) {
                    Text("+", style = MaterialTheme.typography.titleLarge)
                }
                IconButton(
                    onClick = onDelete,
                    modifier = Modifier.size(48.dp)
                ) {
                    Icon(
                        Icons.Default.Delete,
                        contentDescription = stringResource(R.string.action_delete),
                        tint = MaterialTheme.colorScheme.error
                    )
                }
            }
        }
    }
}

@Composable
private fun AddOrEditItemDialog(
    initialItem: Item?,
    initialBarcode: String?,
    defaultThreshold: Int,
    onDismiss: () -> Unit,
    onSaveNew: (name: String, qty: Int, unit: String, sellPrice: Double?, costPrice: Double?, barcode: String?) -> Unit,
    onSaveEdit: (Item) -> Unit
) {
    var name by remember { mutableStateOf(initialItem?.name.orEmpty()) }
    var qtyText by remember { mutableStateOf((initialItem?.qty ?: 0).toString()) }
    var unit by remember { mutableStateOf(initialItem?.unit ?: Item.DEFAULT_UNIT) }
    var sellPriceText by remember { mutableStateOf(initialItem?.sellPrice?.toString().orEmpty()) }
    var costPriceText by remember { mutableStateOf(initialItem?.costPrice?.toString().orEmpty()) }
    var barcodeText by remember { mutableStateOf(initialBarcode ?: initialItem?.barcode.orEmpty()) }
    var thresholdText by remember { mutableStateOf((initialItem?.lowThreshold ?: defaultThreshold).toString()) }
    var aliasesText by remember { mutableStateOf(initialItem?.aliases?.joinToString(", ").orEmpty()) }
    var unitMenuExpanded by remember { mutableStateOf(false) }
    var nameError by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                stringResource(
                    if (initialItem == null) R.string.stock_dialog_add_title else R.string.stock_dialog_edit_title
                )
            )
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(
                    value = name,
                    onValueChange = {
                        name = it
                        nameError = false
                    },
                    label = { Text(stringResource(R.string.stock_field_name)) },
                    isError = nameError,
                    supportingText = if (nameError) {
                        { Text(stringResource(R.string.stock_err_name_required)) }
                    } else {
                        null
                    },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = qtyText,
                        onValueChange = { qtyText = it.filter { ch -> ch.isDigit() } },
                        label = { Text(stringResource(R.string.stock_field_qty)) },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    Box(modifier = Modifier.weight(1f)) {
                        OutlinedTextField(
                            value = unit,
                            onValueChange = {},
                            readOnly = true,
                            label = { Text(stringResource(R.string.unit_label)) },
                            trailingIcon = {
                                IconButton(onClick = { unitMenuExpanded = true }) {
                                    Icon(Icons.Default.KeyboardArrowDown, contentDescription = null)
                                }
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { unitMenuExpanded = true }
                        )
                        DropdownMenu(
                            expanded = unitMenuExpanded,
                            onDismissRequest = { unitMenuExpanded = false }
                        ) {
                            Item.AVAILABLE_UNITS.forEach { option ->
                                DropdownMenuItem(
                                    text = { Text(option) },
                                    onClick = {
                                        unit = option
                                        unitMenuExpanded = false
                                    }
                                )
                            }
                        }
                    }
                }

                OutlinedTextField(
                    value = sellPriceText,
                    onValueChange = { sellPriceText = it },
                    label = { Text(stringResource(R.string.stock_field_sell_price)) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = costPriceText,
                    onValueChange = { costPriceText = it },
                    label = { Text(stringResource(R.string.stock_field_cost_price)) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = barcodeText,
                    onValueChange = { barcodeText = it },
                    label = { Text(stringResource(R.string.stock_field_barcode)) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                if (initialItem != null) {
                    OutlinedTextField(
                        value = thresholdText,
                        onValueChange = { thresholdText = it.filter { ch -> ch.isDigit() } },
                        label = { Text(stringResource(R.string.stock_field_threshold)) },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = aliasesText,
                        onValueChange = { aliasesText = it },
                        label = { Text(stringResource(R.string.stock_field_aliases)) },
                        singleLine = false,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        },
        confirmButton = {
            Button(onClick = {
                val trimmed = name.trim()
                if (trimmed.isEmpty()) {
                    nameError = true
                    return@Button
                }
                val qty = qtyText.toIntOrNull()?.coerceAtLeast(0) ?: 0
                val sell = sellPriceText.trim().toDoubleOrNull()
                val cost = costPriceText.trim().toDoubleOrNull()
                if (initialItem == null) {
                    onSaveNew(trimmed, qty, unit, sell, cost, barcodeText.trim().takeIf { it.isNotEmpty() })
                } else {
                    val threshold = thresholdText.toIntOrNull()?.coerceAtLeast(0) ?: defaultThreshold
                    val aliases = aliasesText.split(",")
                        .map { it.trim() }
                        .filter { it.isNotEmpty() }
                    onSaveEdit(
                        initialItem.copy(
                            name = trimmed,
                            unit = unit,
                            qty = qty,
                            lowThreshold = threshold,
                            sellPrice = sell,
                            costPrice = cost,
                            aliases = aliases,
                            barcode = barcodeText.trim().takeIf { it.isNotEmpty() }
                        )
                    )
                }
            }) {
                Text(stringResource(R.string.action_save))
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text(stringResource(R.string.action_cancel))
            }
        }
    )
}
