package com.example.smartstock.util

import java.text.DecimalFormat
import java.text.DecimalFormatSymbols
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale

data class EthiopianDate(
    val year: Int,
    val month: Int, // 1..13
    val day: Int    // 1..30 (or 1..5/6 in Pagume)
)

object EthiopianCalendar {

    val MONTH_NAMES: List<String> = listOf(
        "መስከረም",
        "ጥቅምት",
        "ኅዳር",
        "ታኅሣሥ",
        "ጥር",
        "የካቲት",
        "መጋቢት",
        "ሚያዝያ",
        "ግንቦት",
        "ሰኔ",
        "ሐምሌ",
        "ነሐሴ",
        "ጳጉሜን"
    )

    // DayOfWeek.value: 1=Monday .. 7=Sunday
    val WEEKDAY_SHORT: List<String> = listOf(
        "ሰኞ",
        "ማክ",
        "ረቡ",
        "ሐሙ",
        "ዓር",
        "ቅዳ",
        "እሑ"
    )

    val WEEKDAY_FULL: List<String> = listOf(
        "ሰኞ",
        "ማክሰኞ",
        "ረቡዕ",
        "ሐሙስ",
        "ዓርብ",
        "ቅዳሜ",
        "እሑድ"
    )

    private const val JD_EPOCH_OFFSET_ETHIOPIC = 1723856L

    /**
     * Pure-Kotlin Gregorian to Ethiopian calendar conversion via Julian Day Number.
     */
    fun fromGregorian(year: Int, month: Int, day: Int): EthiopianDate {
        val jdn = gregorianToJdn(year, month, day)
        val r = (jdn - JD_EPOCH_OFFSET_ETHIOPIC) % 1461L
        val n = (r % 365L) + 365L * (r / 1460L)
        val ethYear = (4L * ((jdn - JD_EPOCH_OFFSET_ETHIOPIC) / 1461L) + (r / 365L) - (r / 1460L)).toInt()
        val ethMonth = (n / 30L).toInt() + 1
        val ethDay = (n % 30L).toInt() + 1
        return EthiopianDate(ethYear, ethMonth, ethDay)
    }

    fun fromLocalDate(date: LocalDate): EthiopianDate {
        return fromGregorian(date.year, date.monthValue, date.dayOfMonth)
    }

    fun formatDate(date: LocalDate, useEthiopian: Boolean): String {
        return if (useEthiopian) {
            val eth = fromLocalDate(date)
            val monthName = MONTH_NAMES.getOrElse(eth.month - 1) { "" }
            "$monthName ${eth.day}፣ ${eth.year}"
        } else {
            date.format(DateTimeFormatter.ofPattern("yyyy-MM-dd", Locale.US))
        }
    }

    fun formatTimestampDate(epochMillis: Long, useEthiopian: Boolean, zoneId: ZoneId = ZoneId.systemDefault()): String {
        val localDate = Instant.ofEpochMilli(epochMillis).atZone(zoneId).toLocalDate()
        return formatDate(localDate, useEthiopian)
    }

    fun formatTimestampTime(epochMillis: Long, zoneId: ZoneId = ZoneId.systemDefault()): String {
        val time = Instant.ofEpochMilli(epochMillis).atZone(zoneId).toLocalTime()
        return time.format(DateTimeFormatter.ofPattern("HH:mm", Locale.US))
    }

    fun weekdayShort(date: LocalDate): String {
        return WEEKDAY_SHORT.getOrElse(date.dayOfWeek.value - 1) { "" }
    }

    private fun gregorianToJdn(year: Int, month: Int, day: Int): Long {
        val a = (14 - month) / 12
        val y = year + 4800 - a
        val m = month + 12 * a - 3
        return day.toLong() +
            (153L * m + 2L) / 5L +
            365L * y +
            y / 4L -
            y / 100L +
            y / 400L -
            32045L
    }
}

object Formatters {
    private val integerSymbols = DecimalFormatSymbols(Locale.US).apply {
        groupingSeparator = ','
        decimalSeparator = '.'
    }

    fun formatMoney(amount: Double): String {
        val rounded = kotlin.math.round(amount * 100.0) / 100.0
        return if (rounded % 1.0 == 0.0) {
            DecimalFormat("#,##0", integerSymbols).format(rounded.toLong())
        } else {
            DecimalFormat("#,##0.##", integerSymbols).format(rounded)
        }
    }

    fun formatInt(value: Int): String {
        return DecimalFormat("#,##0", integerSymbols).format(value.toLong())
    }
}
