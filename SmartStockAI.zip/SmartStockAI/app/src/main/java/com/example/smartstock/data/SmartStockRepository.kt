package com.example.smartstock.data

import android.content.Context
import java.io.File
import java.io.FileOutputStream

/**
 * Persistence layer:
 * - Items & Settings: SharedPreferences "smartstock_v2" as JSON strings with schemaVersion.
 * - History: filesDir/history.json, written atomically via temp file + rename.
 * - Credits: filesDir/credits.json, written atomically via temp file + rename.
 * - Thumbnails: filesDir/evidence/ (JPEG, max 320 px, quality 70).
 * - Receipts: filesDir/receipts/ (PDF).
 */
class SmartStockRepository(context: Context) {

    private val appContext = context.applicationContext
    private val prefs = appContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    private val historyFile = File(appContext.filesDir, HISTORY_FILE_NAME)
    private val historyTempFile = File(appContext.filesDir, "$HISTORY_FILE_NAME.tmp")
    private val creditsFile = File(appContext.filesDir, CREDITS_FILE_NAME)
    private val creditsTempFile = File(appContext.filesDir, "$CREDITS_FILE_NAME.tmp")
    val evidenceDir: File = File(appContext.filesDir, EVIDENCE_DIR_NAME).apply { mkdirs() }
    val receiptsDir: File = File(appContext.filesDir, RECEIPTS_DIR_NAME).apply { mkdirs() }

    private val lock = Any()

    fun loadItems(): List<Item> = synchronized(lock) {
        JsonCodec.decodeItems(prefs.getString(KEY_ITEMS, null))
    }

    fun saveItems(items: List<Item>) {
        synchronized(lock) {
            val json = JsonCodec.encodeItems(items)
            prefs.edit().putString(KEY_ITEMS, json).commit()
            Unit
        }
    }

    fun loadSettings(): AppSettings = synchronized(lock) {
        JsonCodec.decodeSettings(prefs.getString(KEY_SETTINGS, null))
    }

    fun saveSettings(settings: AppSettings) {
        synchronized(lock) {
            val json = JsonCodec.encodeSettings(settings)
            prefs.edit().putString(KEY_SETTINGS, json).commit()
            Unit
        }
    }

    fun loadHistory(): List<Txn> = synchronized(lock) {
        if (!historyFile.exists()) return emptyList()
        return try {
            val content = historyFile.readText(Charsets.UTF_8)
            JsonCodec.decodeHistory(content).sortedByDescending { it.timestamp }
        } catch (_: Exception) {
            emptyList()
        }
    }

    fun saveHistoryAtomic(history: List<Txn>) {
        synchronized(lock) {
            writeAtomicFile(historyTempFile, historyFile, JsonCodec.encodeHistory(history))
            Unit
        }
    }

    fun loadCredits(): List<CustomerCredit> = synchronized(lock) {
        if (!creditsFile.exists()) return emptyList()
        return try {
            val content = creditsFile.readText(Charsets.UTF_8)
            JsonCodec.decodeCredits(content).sortedByDescending { it.createdAt }
        } catch (_: Exception) {
            emptyList()
        }
    }

    fun saveCreditsAtomic(credits: List<CustomerCredit>) {
        synchronized(lock) {
            writeAtomicFile(creditsTempFile, creditsFile, JsonCodec.encodeCredits(credits))
            Unit
        }
    }

    fun commitItemsAndHistory(items: List<Item>, history: List<Txn>) {
        synchronized(lock) {
            writeAtomicFile(historyTempFile, historyFile, JsonCodec.encodeHistory(history))
            prefs.edit().putString(KEY_ITEMS, JsonCodec.encodeItems(items)).commit()
            Unit
        }
    }

    fun evidenceFile(fileName: String): File = File(evidenceDir, fileName)

    fun exportBackupJson(
        items: List<Item>,
        settings: AppSettings,
        history: List<Txn>,
        credits: List<CustomerCredit>
    ): String {
        return JsonCodec.encodeBackup(items, settings, history, credits)
    }

    fun restoreFromBackup(payload: BackupPayload) {
        synchronized(lock) {
            writeAtomicFile(historyTempFile, historyFile, JsonCodec.encodeHistory(payload.history))
            writeAtomicFile(creditsTempFile, creditsFile, JsonCodec.encodeCredits(payload.credits))
            prefs.edit()
                .putString(KEY_ITEMS, JsonCodec.encodeItems(payload.items))
                .putString(KEY_SETTINGS, JsonCodec.encodeSettings(payload.settings))
                .commit()
            Unit
        }
    }

    fun clearAllData() {
        synchronized(lock) {
            prefs.edit().remove(KEY_ITEMS).commit()
            if (historyFile.exists()) historyFile.delete()
            if (historyTempFile.exists()) historyTempFile.delete()
            if (creditsFile.exists()) creditsFile.delete()
            if (creditsTempFile.exists()) creditsTempFile.delete()
            evidenceDir.listFiles()?.forEach { it.delete() }
            receiptsDir.listFiles()?.forEach { it.delete() }
            Unit
        }
    }

    private fun writeAtomicFile(tempFile: File, targetFile: File, content: String) {
        FileOutputStream(tempFile).use { fos ->
            fos.write(content.toByteArray(Charsets.UTF_8))
            fos.flush()
            try {
                fos.fd.sync()
            } catch (_: Exception) {
                // Ignore sync errors on virtual filesystems
            }
        }
        if (targetFile.exists()) {
            if (!tempFile.renameTo(targetFile)) {
                targetFile.delete()
                tempFile.renameTo(targetFile)
            }
        } else {
            tempFile.renameTo(targetFile)
        }
    }

    companion object {
        private const val PREFS_NAME = "smartstock_v2"
        private const val KEY_ITEMS = "items_json"
        private const val KEY_SETTINGS = "settings_json"
        private const val HISTORY_FILE_NAME = "history.json"
        private const val CREDITS_FILE_NAME = "credits.json"
        private const val EVIDENCE_DIR_NAME = "evidence"
        private const val RECEIPTS_DIR_NAME = "receipts"
    }
}
