package com.example.smartstock.ui.screens

import android.Manifest
import android.net.Uri
import android.os.Build
import androidx.compose.material3.Switch
import com.example.smartstock.data.ThemeMode
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import com.example.smartstock.R
import com.example.smartstock.data.AppLanguage
import com.example.smartstock.data.DateStyle
import com.example.smartstock.ui.AppUiState
import com.example.smartstock.ui.KeyTestStatus
import com.example.smartstock.ui.theme.MatchGreen
import com.example.smartstock.ui.theme.ShortageRed

@Composable
fun SettingsScreen(
    state: AppUiState,
    initialApiKey: String,
    onSaveApiKey: (String) -> Unit,
    onTestApiKey: (String) -> Unit,
    onSelectModel: (String) -> Unit,
    onResetModel: () -> Unit,
    onUpdateThreshold: (Int) -> Unit,
    onUpdateLanguage: (AppLanguage) -> Unit,
    onUpdateDateStyle: (DateStyle) -> Unit,
    onUpdateThemeMode: (ThemeMode) -> Unit,
    onUpdateLowStockNotif: (Boolean) -> Unit,
    onTestLowStockNotif: () -> Unit,
    onBackupToUri: (Uri) -> Unit,
    onRestoreFromUri: (Uri) -> Unit,
    onClearAllData: () -> Unit
) {
    var apiKeyText by remember { mutableStateOf(initialApiKey) }
    var showKey by remember { mutableStateOf(false) }
    var thresholdText by remember(state.settings.defaultLowThreshold) {
        mutableStateOf(state.settings.defaultLowThreshold.toString())
    }
    var pendingRestoreUri by remember { mutableStateOf<Uri?>(null) }
    var showClearConfirm by remember { mutableStateOf(false) }

    val notifPermLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        onUpdateLowStockNotif(granted)
    }

    val backupLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/json")
    ) { uri ->
        if (uri != null) onBackupToUri(uri)
    }

    val restoreLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) pendingRestoreUri = uri
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // API Key Section
        item(key = "settings_api") {
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = stringResource(R.string.settings_api_section),
                        style = MaterialTheme.typography.titleMedium
                    )
                    OutlinedTextField(
                        value = apiKeyText,
                        onValueChange = { apiKeyText = it },
                        label = { Text(stringResource(R.string.settings_api_key_label)) },
                        singleLine = true,
                        visualTransformation = if (showKey) VisualTransformation.None else PasswordVisualTransformation(),
                        trailingIcon = {
                            TextButton(onClick = { showKey = !showKey }) {
                                Text(
                                    stringResource(
                                        if (showKey) R.string.settings_btn_hide else R.string.settings_btn_show
                                    )
                                )
                            }
                        },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Text(
                        text = stringResource(R.string.settings_api_key_note),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Button(
                            onClick = { onSaveApiKey(apiKeyText) },
                            modifier = Modifier
                                .weight(1f)
                                .heightIn(min = 48.dp)
                        ) {
                            Text(stringResource(R.string.action_save))
                        }
                        OutlinedButton(
                            onClick = { onTestApiKey(apiKeyText) },
                            enabled = state.keyTestStatus != KeyTestStatus.TESTING,
                            modifier = Modifier
                                .weight(1f)
                                .heightIn(min = 48.dp)
                        ) {
                            if (state.keyTestStatus == KeyTestStatus.TESTING) {
                                CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
                                Spacer(modifier = Modifier.width(6.dp))
                            }
                            Text(stringResource(R.string.settings_btn_test_key))
                        }
                    }
                    state.keyTestMessage?.let { msg ->
                        val color = when (state.keyTestStatus) {
                            KeyTestStatus.SUCCESS -> MatchGreen
                            KeyTestStatus.FAILED -> ShortageRed
                            else -> MaterialTheme.colorScheme.onSurfaceVariant
                        }
                        Text(text = msg, style = MaterialTheme.typography.bodyMedium, color = color)
                    }
                }
            }
        }

        // Model Section
        item(key = "settings_model") {
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = stringResource(R.string.settings_model_section),
                        style = MaterialTheme.typography.titleMedium
                    )
                    Text(
                        text = stringResource(R.string.settings_active_model, state.settings.activeModel),
                        style = MaterialTheme.typography.bodyLarge
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        listOf("gemini-3.5-flash-lite", "gemini-3.8-flash", "gemini-3.6-flash").forEach { modelOption ->
                            FilterChip(
                                selected = state.settings.activeModel == modelOption,
                                onClick = { onSelectModel(modelOption) },
                                label = { Text(modelOption.removePrefix("gemini-")) }
                            )
                        }
                    }
                    OutlinedButton(
                        onClick = onResetModel,
                        modifier = Modifier.heightIn(min = 48.dp)
                    ) {
                        Text(stringResource(R.string.settings_btn_reset_model))
                    }
                }
            }
        }

        // General Settings (Threshold + Date Style)
        item(key = "settings_general") {
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(
                        text = stringResource(R.string.settings_general_section),
                        style = MaterialTheme.typography.titleMedium
                    )
                    Text(
                        text = stringResource(R.string.settings_language_label),
                        style = MaterialTheme.typography.labelLarge
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        FilterChip(
                            selected = state.settings.language == AppLanguage.AMHARIC,
                            onClick = { onUpdateLanguage(AppLanguage.AMHARIC) },
                            label = { Text(stringResource(R.string.settings_lang_amharic)) }
                        )
                        FilterChip(
                            selected = state.settings.language == AppLanguage.ENGLISH,
                            onClick = { onUpdateLanguage(AppLanguage.ENGLISH) },
                            label = { Text(stringResource(R.string.settings_lang_english)) }
                        )
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        OutlinedTextField(
                            value = thresholdText,
                            onValueChange = { thresholdText = it.filter { ch -> ch.isDigit() } },
                            label = { Text(stringResource(R.string.settings_threshold_label)) },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                        Button(
                            onClick = {
                                val parsed = thresholdText.toIntOrNull() ?: 3
                                onUpdateThreshold(parsed)
                            },
                            modifier = Modifier.heightIn(min = 48.dp)
                        ) {
                            Text(stringResource(R.string.action_save))
                        }
                    }

                    Text(
                        text = stringResource(R.string.settings_date_style_label),
                        style = MaterialTheme.typography.labelLarge
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        FilterChip(
                            selected = state.settings.dateStyle == DateStyle.ETHIOPIAN,
                            onClick = { onUpdateDateStyle(DateStyle.ETHIOPIAN) },
                            label = { Text(stringResource(R.string.settings_date_ethiopian)) }
                        )
                        FilterChip(
                            selected = state.settings.dateStyle == DateStyle.GREGORIAN,
                            onClick = { onUpdateDateStyle(DateStyle.GREGORIAN) },
                            label = { Text(stringResource(R.string.settings_date_gregorian)) }
                        )
                    }

                    Text(
                        text = stringResource(R.string.settings_theme_label),
                        style = MaterialTheme.typography.labelLarge
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(
                            selected = state.settings.themeMode == ThemeMode.SYSTEM,
                            onClick = { onUpdateThemeMode(ThemeMode.SYSTEM) },
                            label = { Text(stringResource(R.string.settings_theme_system)) }
                        )
                        FilterChip(
                            selected = state.settings.themeMode == ThemeMode.LIGHT,
                            onClick = { onUpdateThemeMode(ThemeMode.LIGHT) },
                            label = { Text(stringResource(R.string.settings_theme_light)) }
                        )
                        FilterChip(
                            selected = state.settings.themeMode == ThemeMode.DARK,
                            onClick = { onUpdateThemeMode(ThemeMode.DARK) },
                            label = { Text(stringResource(R.string.settings_theme_dark)) }
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = stringResource(R.string.settings_notif_label),
                                style = MaterialTheme.typography.labelLarge
                            )
                            Text(
                                text = stringResource(R.string.settings_notif_desc),
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Switch(
                            checked = state.settings.lowStockNotificationsEnabled,
                            onCheckedChange = { enable ->
                                if (enable && Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                                    notifPermLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                                } else {
                                    onUpdateLowStockNotif(enable)
                                }
                            }
                        )
                    }
                    OutlinedButton(
                        onClick = onTestLowStockNotif,
                        modifier = Modifier.heightIn(min = 48.dp)
                    ) {
                        Text(stringResource(R.string.settings_notif_test))
                    }
                }
            }
        }

        // Backup / Restore & Clear All Data
        item(key = "settings_backup") {
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = stringResource(R.string.settings_backup_section),
                        style = MaterialTheme.typography.titleMedium
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Button(
                            onClick = { backupLauncher.launch("smartstock_backup.json") },
                            modifier = Modifier
                                .weight(1f)
                                .heightIn(min = 48.dp)
                        ) {
                            Text(stringResource(R.string.settings_btn_backup))
                        }
                        OutlinedButton(
                            onClick = { restoreLauncher.launch(arrayOf("application/json", "*/*")) },
                            modifier = Modifier
                                .weight(1f)
                                .heightIn(min = 48.dp)
                        ) {
                            Text(stringResource(R.string.settings_btn_restore))
                        }
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Button(
                        onClick = { showClearConfirm = true },
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(min = 48.dp)
                    ) {
                        Text(stringResource(R.string.settings_btn_clear_all))
                    }
                }
            }
        }
    }

    pendingRestoreUri?.let { uri ->
        AlertDialog(
            onDismissRequest = { pendingRestoreUri = null },
            title = { Text(stringResource(R.string.settings_restore_confirm_title)) },
            text = { Text(stringResource(R.string.settings_restore_confirm_body)) },
            confirmButton = {
                Button(onClick = {
                    onRestoreFromUri(uri)
                    pendingRestoreUri = null
                }) {
                    Text(stringResource(R.string.action_confirm))
                }
            },
            dismissButton = {
                TextButton(onClick = { pendingRestoreUri = null }) {
                    Text(stringResource(R.string.action_cancel))
                }
            }
        )
    }

    if (showClearConfirm) {
        AlertDialog(
            onDismissRequest = { showClearConfirm = false },
            title = { Text(stringResource(R.string.settings_clear_title)) },
            text = { Text(stringResource(R.string.settings_clear_body)) },
            confirmButton = {
                Button(
                    onClick = {
                        onClearAllData()
                        showClearConfirm = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) {
                    Text(stringResource(R.string.action_delete))
                }
            },
            dismissButton = {
                TextButton(onClick = { showClearConfirm = false }) {
                    Text(stringResource(R.string.action_cancel))
                }
            }
        )
    }
}
