package com.example.smartstock.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.example.smartstock.R
import com.example.smartstock.domain.CreditAndReportEngine
import com.example.smartstock.domain.ReportPeriod
import com.example.smartstock.domain.SalesProfitPoint
import com.example.smartstock.ui.AppUiState
import com.example.smartstock.ui.components.EmptyStateCard
import com.example.smartstock.ui.theme.MatchGreen
import com.example.smartstock.util.Formatters
import java.util.Locale

@Composable
fun ReportsScreen(state: AppUiState) {
    var period by rememberSaveable { mutableStateOf(ReportPeriod.DAYS_7) }
    val report = remember(state.items, state.history, period) {
        CreditAndReportEngine.computePeriodReport(state.items, state.history, period)
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item(key = "period_selector") {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(
                    selected = period == ReportPeriod.DAYS_7,
                    onClick = { period = ReportPeriod.DAYS_7 },
                    label = { Text(stringResource(R.string.reports_period_7d)) }
                )
                FilterChip(
                    selected = period == ReportPeriod.DAYS_30,
                    onClick = { period = ReportPeriod.DAYS_30 },
                    label = { Text(stringResource(R.string.reports_period_30d)) }
                )
                FilterChip(
                    selected = period == ReportPeriod.ALL_TIME,
                    onClick = { period = ReportPeriod.ALL_TIME },
                    label = { Text(stringResource(R.string.reports_period_all)) }
                )
            }
        }

        if (report.saleCount == 0) {
            item(key = "reports_empty") {
                EmptyStateCard(
                    title = stringResource(R.string.reports_empty_title),
                    body = stringResource(R.string.reports_empty_body)
                )
            }
        } else {
            item(key = "reports_kpi_row1") {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Card(
                        modifier = Modifier.weight(1f),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Text(
                                text = stringResource(R.string.reports_kpi_revenue),
                                style = MaterialTheme.typography.labelLarge
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = stringResource(R.string.money_format, Formatters.formatMoney(report.totalRevenueEtb)),
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    Card(
                        modifier = Modifier.weight(1f),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Text(
                                text = stringResource(R.string.reports_kpi_profit),
                                style = MaterialTheme.typography.labelLarge
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            val profit = report.totalEstimatedProfitEtb
                            Text(
                                text = if (profit != null) {
                                    stringResource(R.string.money_format, Formatters.formatMoney(profit))
                                } else {
                                    stringResource(R.string.dashboard_profit_unknown)
                                },
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            report.profitMarginPercent?.let { margin ->
                                Text(
                                    text = stringResource(
                                        R.string.reports_kpi_margin,
                                        String.format(Locale.US, "%.1f", margin)
                                    ),
                                    style = MaterialTheme.typography.labelMedium
                                )
                            }
                        }
                    }
                }
            }

            item(key = "reports_kpi_row2") {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Card(modifier = Modifier.weight(1f)) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Text(
                                text = stringResource(R.string.reports_kpi_count),
                                style = MaterialTheme.typography.labelLarge,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = Formatters.formatInt(report.saleCount),
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                    Card(modifier = Modifier.weight(1f)) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Text(
                                text = stringResource(R.string.reports_kpi_avg),
                                style = MaterialTheme.typography.labelLarge,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = stringResource(R.string.money_format, Formatters.formatMoney(report.averageSaleEtb)),
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }

            // Dual-Series Sales vs Profit Canvas Chart
            item(key = "reports_chart") {
                Card(modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = stringResource(R.string.reports_chart_title),
                            style = MaterialTheme.typography.titleMedium
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(16.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(10.dp)
                                        .clip(CircleShape)
                                        .background(MaterialTheme.colorScheme.primary)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(stringResource(R.string.reports_legend_sales), style = MaterialTheme.typography.labelMedium)
                            }
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(10.dp)
                                        .clip(CircleShape)
                                        .background(MatchGreen)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(stringResource(R.string.reports_legend_profit), style = MaterialTheme.typography.labelMedium)
                            }
                        }
                        Spacer(modifier = Modifier.height(12.dp))
                        SalesProfitDualBarChart(points = report.chartPoints)
                    }
                }
            }

            // Top 5 Items Table
            item(key = "reports_top_items") {
                Card(modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(
                            text = stringResource(R.string.reports_top_items_title),
                            style = MaterialTheme.typography.titleMedium
                        )
                        report.topItems.forEachIndexed { idx, row ->
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = "${idx + 1}. ${row.name}",
                                        style = MaterialTheme.typography.bodyLarge,
                                        fontWeight = FontWeight.Medium
                                    )
                                    Text(
                                        text = "${stringResource(R.string.qty_label)}: ${Formatters.formatInt(row.qtySold)}",
                                        style = MaterialTheme.typography.labelMedium,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                Column(horizontalAlignment = Alignment.End) {
                                    Text(
                                        text = stringResource(R.string.money_format, Formatters.formatMoney(row.revenueEtb)),
                                        style = MaterialTheme.typography.bodyMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                    row.estimatedProfitEtb?.let { p ->
                                        Text(
                                            text = "${stringResource(R.string.profit_label)}: ${Formatters.formatMoney(p)}",
                                            style = MaterialTheme.typography.labelMedium,
                                            color = MatchGreen
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SalesProfitDualBarChart(points: List<SalesProfitPoint>) {
    val maxVal = points.maxOfOrNull { maxOf(it.salesEtb, it.profitEtb) } ?: 0.0
    if (maxVal <= 0.0 || points.isEmpty()) return

    val salesColor = MaterialTheme.colorScheme.primary
    val profitColor = MatchGreen
    val trackColor = MaterialTheme.colorScheme.surfaceVariant

    Column(modifier = Modifier.fillMaxWidth()) {
        Canvas(
            modifier = Modifier
                .fillMaxWidth()
                .height(160.dp)
        ) {
            val count = points.size.coerceAtLeast(1)
            val slotW = size.width / count
            val barW = (slotW * 0.32f).coerceAtLeast(6f)
            val gap = (slotW * 0.06f).coerceAtLeast(2f)
            val corner = CornerRadius(6f, 6f)

            points.forEachIndexed { idx, pt ->
                val groupLeft = idx * slotW + (slotW - (barW * 2 + gap)) / 2f
                // Sales track + bar
                drawRoundRect(
                    color = trackColor,
                    topLeft = Offset(groupLeft, 0f),
                    size = Size(barW, size.height),
                    cornerRadius = corner
                )
                val salesH = ((pt.salesEtb / maxVal).toFloat().coerceIn(0f, 1f) * size.height)
                    .coerceAtLeast(if (pt.salesEtb > 0) 6f else 0f)
                if (salesH > 0f) {
                    drawRoundRect(
                        color = salesColor,
                        topLeft = Offset(groupLeft, size.height - salesH),
                        size = Size(barW, salesH),
                        cornerRadius = corner
                    )
                }

                // Profit track + bar
                val profitLeft = groupLeft + barW + gap
                drawRoundRect(
                    color = trackColor,
                    topLeft = Offset(profitLeft, 0f),
                    size = Size(barW, size.height),
                    cornerRadius = corner
                )
                val profitH = ((pt.profitEtb / maxVal).toFloat().coerceIn(0f, 1f) * size.height)
                    .coerceAtLeast(if (pt.profitEtb > 0) 6f else 0f)
                if (profitH > 0f) {
                    drawRoundRect(
                        color = profitColor,
                        topLeft = Offset(profitLeft, size.height - profitH),
                        size = Size(barW, profitH),
                        cornerRadius = corner
                    )
                }
            }
        }
        Spacer(modifier = Modifier.height(6.dp))
        Row(modifier = Modifier.fillMaxWidth()) {
            points.forEach { pt ->
                Text(
                    text = pt.label,
                    style = MaterialTheme.typography.labelMedium,
                    textAlign = TextAlign.Center,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.weight(1f)
                )
            }
        }
    }
}
