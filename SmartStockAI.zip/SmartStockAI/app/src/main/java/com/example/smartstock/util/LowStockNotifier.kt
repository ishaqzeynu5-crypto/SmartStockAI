package com.example.smartstock.util

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.example.smartstock.R
import com.example.smartstock.data.Item

object LowStockNotifier {

    private const val CHANNEL_ID = "smartstock_low_stock"
    private const val NOTIFICATION_ID = 2001

    fun notifyIfLowStock(context: Context, items: List<Item>, enabled: Boolean) {
        if (!enabled) return
        val lowItems = items.filter { it.qty < it.lowThreshold }.sortedBy { it.qty }
        if (lowItems.isEmpty()) return

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val granted = ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
            if (!granted) return
        }

        ensureChannel(context)

        val previewNames = lowItems.take(3).joinToString(", ") { "${it.name} (${it.qty})" }
        val extraCount = (lowItems.size - 3).coerceAtLeast(0)
        val body = if (extraCount > 0) {
            context.getString(R.string.notif_low_stock_body_more, previewNames, extraCount)
        } else {
            context.getString(R.string.notif_low_stock_body, previewNames)
        }

        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentTitle(context.getString(R.string.notif_low_stock_title, lowItems.size))
            .setContentText(body)
            .setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setAutoCancel(true)
            .build()

        try {
            NotificationManagerCompat.from(context).notify(NOTIFICATION_ID, notification)
        } catch (_: SecurityException) {
            // Permission revoked concurrently
        }
    }

    private fun ensureChannel(context: Context) {
        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager ?: return
        val existing = manager.getNotificationChannel(CHANNEL_ID)
        if (existing != null) return
        val channel = NotificationChannel(
            CHANNEL_ID,
            context.getString(R.string.notif_channel_name),
            NotificationManager.IMPORTANCE_DEFAULT
        ).apply {
            description = context.getString(R.string.notif_channel_desc)
        }
        manager.createNotificationChannel(channel)
    }
}
