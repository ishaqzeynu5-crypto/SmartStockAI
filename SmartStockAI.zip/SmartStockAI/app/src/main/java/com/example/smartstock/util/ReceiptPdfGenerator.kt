package com.example.smartstock.util

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.os.Bundle
import android.os.CancellationSignal
import android.os.ParcelFileDescriptor
import android.print.PageRange
import android.print.PrintAttributes
import android.print.PrintDocumentAdapter
import android.print.PrintDocumentInfo
import android.print.PrintManager
import androidx.core.content.FileProvider
import com.example.smartstock.R
import com.example.smartstock.data.Txn
import com.example.smartstock.data.TxnStatus
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream

object ReceiptPdfGenerator {

    private const val PAGE_WIDTH = 420
    private const val PAGE_HEIGHT = 600
    private const val MARGIN = 24f

    suspend fun generateReceiptPdf(
        context: Context,
        txn: Txn,
        receiptsDir: File,
        useEthiopianDate: Boolean
    ): File = withContext(Dispatchers.IO) {
        receiptsDir.mkdirs()
        val outFile = File(receiptsDir, "receipt_${txn.id.take(8)}.pdf")

        val doc = PdfDocument()
        var pageNum = 1
        var pageInfo = PdfDocument.PageInfo.Builder(PAGE_WIDTH, PAGE_HEIGHT, pageNum).create()
        var page = doc.startPage(pageInfo)
        var canvas = page.canvas

        val titlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(0, 105, 92)
            textSize = 18f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }
        val headerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.BLACK
            textSize = 12f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }
        val bodyPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.DKGRAY
            textSize = 11f
        }
        val totalPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.BLACK
            textSize = 15f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }
        val linePaint = Paint().apply {
            color = Color.LTGRAY
            strokeWidth = 1f
        }

        var y = 40f

        // Header
        canvas.drawText(context.getString(R.string.app_name), MARGIN, y, titlePaint)
        y += 20f
        canvas.drawText(context.getString(R.string.receipt_title), MARGIN, y, headerPaint)
        y += 18f

        val dateStr = EthiopianCalendar.formatTimestampDate(txn.timestamp, useEthiopianDate)
        val timeStr = EthiopianCalendar.formatTimestampTime(txn.timestamp)
        canvas.drawText(context.getString(R.string.receipt_date_time, dateStr, timeStr), MARGIN, y, bodyPaint)
        y += 15f
        canvas.drawText(context.getString(R.string.receipt_number, txn.id.take(8).uppercase()), MARGIN, y, bodyPaint)
        if (txn.status == TxnStatus.VOIDED) {
            y += 15f
            val voidPaint = Paint(headerPaint).apply { color = Color.RED }
            canvas.drawText(context.getString(R.string.history_voided_badge), MARGIN, y, voidPaint)
        }
        y += 12f
        canvas.drawLine(MARGIN, y, PAGE_WIDTH - MARGIN, y, linePaint)
        y += 18f

        // Table Header
        canvas.drawText(context.getString(R.string.cargo_col_item), MARGIN, y, headerPaint)
        canvas.drawText(context.getString(R.string.qty_label), 220f, y, headerPaint)
        canvas.drawText(context.getString(R.string.price_label), 270f, y, headerPaint)
        canvas.drawText(context.getString(R.string.receipt_col_total), 340f, y, headerPaint)
        y += 8f
        canvas.drawLine(MARGIN, y, PAGE_WIDTH - MARGIN, y, linePaint)
        y += 16f

        // Item Rows
        for (line in txn.lines) {
            if (y > PAGE_HEIGHT - 80f) {
                doc.finishPage(page)
                pageNum++
                pageInfo = PdfDocument.PageInfo.Builder(PAGE_WIDTH, PAGE_HEIGHT, pageNum).create()
                page = doc.startPage(pageInfo)
                canvas = page.canvas
                y = 40f
            }
            val nameClipped = if (line.name.length > 26) line.name.take(25) + "…" else line.name
            val unitPriceStr = line.unitPrice?.let { Formatters.formatMoney(it) } ?: "-"
            val lineTotalStr = Formatters.formatMoney(line.qty * (line.unitPrice ?: 0.0))

            canvas.drawText(nameClipped, MARGIN, y, bodyPaint)
            canvas.drawText(line.qty.toString(), 220f, y, bodyPaint)
            canvas.drawText(unitPriceStr, 270f, y, bodyPaint)
            canvas.drawText(lineTotalStr, 340f, y, bodyPaint)
            y += 18f
        }

        y += 6f
        canvas.drawLine(MARGIN, y, PAGE_WIDTH - MARGIN, y, linePaint)
        y += 22f

        val grandTotalText = context.getString(
            R.string.receipt_grand_total,
            Formatters.formatMoney(txn.totalEtb)
        )
        canvas.drawText(grandTotalText, MARGIN, y, totalPaint)

        txn.note?.let { note ->
            y += 22f
            canvas.drawText(note.take(60), MARGIN, y, bodyPaint)
        }

        y += 30f
        canvas.drawText(context.getString(R.string.receipt_footer_thanks), MARGIN, y, bodyPaint)

        doc.finishPage(page)
        try {
            FileOutputStream(outFile).use { fos ->
                doc.writeTo(fos)
            }
        } finally {
            doc.close()
        }
        outFile
    }

    fun shareReceiptPdf(context: Context, pdfFile: File) {
        val uri: Uri = FileProvider.getUriForFile(
            context,
            "${context.packageName}.fileprovider",
            pdfFile
        )
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "application/pdf"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(
            Intent.createChooser(intent, context.getString(R.string.receipt_share_title))
        )
    }

    fun printReceiptPdf(context: Context, pdfFile: File) {
        val printManager = context.getSystemService(Context.PRINT_SERVICE) as? PrintManager ?: return
        val adapter = object : PrintDocumentAdapter() {
            override fun onLayout(
                oldAttributes: PrintAttributes?,
                newAttributes: PrintAttributes,
                cancellationSignal: CancellationSignal?,
                callback: LayoutResultCallback,
                extras: Bundle?
            ) {
                if (cancellationSignal?.isCanceled == true) {
                    callback.onLayoutCancelled()
                    return
                }
                val info = PrintDocumentInfo.Builder(pdfFile.name)
                    .setContentType(PrintDocumentInfo.CONTENT_TYPE_DOCUMENT)
                    .build()
                callback.onLayoutFinished(info, true)
            }

            override fun onWrite(
                pages: Array<out PageRange>,
                destination: ParcelFileDescriptor,
                cancellationSignal: CancellationSignal?,
                callback: WriteResultCallback
            ) {
                try {
                    FileInputStream(pdfFile).use { input ->
                        FileOutputStream(destination.fileDescriptor).use { output ->
                            input.copyTo(output)
                        }
                    }
                    callback.onWriteFinished(arrayOf(PageRange.ALL_PAGES))
                } catch (e: Exception) {
                    callback.onWriteFailed(e.message)
                }
            }
        }
        printManager.print(context.getString(R.string.receipt_title), adapter, null)
    }
}
