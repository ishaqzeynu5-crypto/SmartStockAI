package com.example.smartstock

import com.example.smartstock.ai.AiErrorType
import com.example.smartstock.ai.AiException
import com.example.smartstock.ai.ResponseParsers
import com.example.smartstock.data.Confidence
import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.fail
import org.junit.Test

class ResponseParsersTest {

    @Test
    fun parseCargoResponse_handlesMarkdownFencesAndMatchesFields() {
        val fenced = """
            ```json
            {
              "sent_items": [{"name": "ዘይት", "qty": 10, "confidence": "high"}],
              "received_items": [{"name": "ዘይት", "matched_stock_id": "id-1", "qty": 9, "confidence": "medium"}],
              "report_am": "1 ዘይት ጎድሏል።",
              "photo_note_am": "ፎቶው ግልጽ ነው።"
            }
            ```
        """.trimIndent()

        val result = ResponseParsers.parseCargoResponse(fenced)
        assertEquals(1, result.sentItems.size)
        assertEquals(10, result.sentItems[0].qty)
        assertEquals(Confidence.HIGH, result.sentItems[0].confidence)
        assertEquals(1, result.receivedItems.size)
        assertEquals("id-1", result.receivedItems[0].matchedStockId)
        assertEquals(9, result.receivedItems[0].qty)
        assertEquals("1 ዘይት ጎድሏል።", result.reportAm)
    }

    @Test
    fun parseSalesResponse_handlesNullsAndValidJson() {
        val json = """
            {
              "lines": [
                {
                  "raw_text": "ስኳር 2 x 1550 = 3100",
                  "name": "ስኳር",
                  "matched_stock_id": null,
                  "qty": 2,
                  "unit_price": 1550,
                  "line_total": 3100,
                  "confidence": "high"
                }
              ],
              "written_grand_total": 3100,
              "notes_am": "ሁሉም መስመሮች በግልጽ ተነበዋል።"
            }
        """.trimIndent()

        val result = ResponseParsers.parseSalesResponse(json)
        assertEquals(1, result.lines.size)
        assertNull(result.lines[0].matchedStockId)
        assertEquals(2, result.lines[0].qty)
        assertEquals(1550.0, result.lines[0].unitPrice!!, 0.01)
        assertEquals(3100.0, result.writtenGrandTotal!!, 0.01)
    }

    @Test
    fun parseMalformedJson_throwsParseFailed() {
        try {
            ResponseParsers.parseSalesResponse("{not valid json")
            fail("Expected AiException")
        } catch (e: AiException) {
            assertEquals(AiErrorType.PARSE_FAILED, e.errorType)
        }
    }

    @Test
    fun extractCandidateText_handlesBlockedAndMaxTokens() {
        val blocked = """{"promptFeedback": {"blockReason": "SAFETY"}}"""
        try {
            ResponseParsers.extractCandidateText(blocked)
            fail("Expected BLOCKED_CONTENT")
        } catch (e: AiException) {
            assertEquals(AiErrorType.BLOCKED_CONTENT, e.errorType)
        }

        val maxTok = """{"candidates": [{"finishReason": "MAX_TOKENS", "content": {"parts": [{"text": "{}"}]}}]}"""
        try {
            ResponseParsers.extractCandidateText(maxTok)
            fail("Expected MAX_TOKENS")
        } catch (e: AiException) {
            assertEquals(AiErrorType.MAX_TOKENS, e.errorType)
        }
    }

    @Test
    fun selectBestFlashModel_filtersExcludedAndRanksProperly() {
        fun modelObj(name: String, supportsGen: Boolean = true): JSONObject {
            val methods = JSONArray()
            if (supportsGen) methods.put("generateContent")
            return JSONObject()
                .put("name", name)
                .put("supportedGenerationMethods", methods)
        }

        val models = listOf(
            modelObj("models/gemini-2.5-flash-image"),
            modelObj("models/gemini-2.5-flash-tts"),
            modelObj("models/gemini-2.5-flash-preview-04-17"),
            modelObj("models/gemini-2.5-flash-lite"),
            modelObj("models/gemini-2.0-flash"),
            modelObj("models/gemini-2.5-flash"),
            modelObj("models/gemini-3.0-flash-exp")
        )

        // Stable 2.5-flash beats preview/exp 3.0, beats 2.5-flash-lite, beats 2.0-flash, excludes image/tts
        assertEquals("gemini-2.5-flash", ResponseParsers.selectBestFlashModel(models))
    }
}
