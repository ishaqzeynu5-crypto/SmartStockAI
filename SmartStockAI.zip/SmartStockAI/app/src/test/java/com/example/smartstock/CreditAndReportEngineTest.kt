package com.example.smartstock

import com.example.smartstock.data.AppSettings
import com.example.smartstock.data.CustomerCredit
import com.example.smartstock.data.Item
import com.example.smartstock.data.JsonCodec
import com.example.smartstock.data.Line
import com.example.smartstock.data.Txn
import com.example.smartstock.data.TxnStatus
import com.example.smartstock.data.TxnType
import com.example.smartstock.domain.CreditAndReportEngine
import com.example.smartstock.domain.ReportPeriod
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.LocalDate
import java.time.ZoneId

class CreditAndReportEngineTest {

    @Test
    fun recordCreditPayment_tracksPartialAndClampsOverpayment() {
        val c = CustomerCredit(id = "c1", customerName = "Abebe", totalOwedEtb = 1000.0)
        val afterPartial = CreditAndReportEngine.recordCreditPayment(listOf(c), "c1", 400.0, "Part 1")
        assertEquals(600.0, afterPartial.first().remainingEtb, 0.01)
        assertFalse(afterPartial.first().isPaidOff)

        val afterFull = CreditAndReportEngine.recordCreditPayment(afterPartial, "c1", 900.0, "Final")
        assertEquals(0.0, afterFull.first().remainingEtb, 0.01)
        assertTrue(afterFull.first().isPaidOff)
        assertEquals(2, afterFull.first().payments.size)
    }

    @Test
    fun computePeriodReport_computesRevenueProfitMarginAndTopItems() {
        val zone = ZoneId.of("UTC")
        val today = LocalDate.of(2026, 11, 23)
        val todayMs = today.atStartOfDay(zone).toInstant().toEpochMilli()

        val sugar = Item(id = "s1", name = "ስኳር", qty = 10, sellPrice = 200.0, costPrice = 150.0)
        val oil = Item(id = "o1", name = "ዘይት", qty = 5, sellPrice = 1000.0, costPrice = 800.0)

        val txn = Txn(
            id = "t1",
            type = TxnType.SALE,
            timestamp = todayMs,
            lines = listOf(
                Line(itemId = "s1", name = "ስኳር", qty = 3, unitPrice = 200.0),
                Line(itemId = "o1", name = "ዘይት", qty = 1, unitPrice = 1000.0)
            ),
            totalEtb = 1600.0,
            status = TxnStatus.ACTIVE
        )

        val report = CreditAndReportEngine.computePeriodReport(
            items = listOf(sugar, oil),
            history = listOf(txn),
            period = ReportPeriod.DAYS_7,
            today = today,
            zoneId = zone
        )

        assertEquals(1600.0, report.totalRevenueEtb, 0.01)
        assertEquals(350.0, report.totalEstimatedProfitEtb!!, 0.01) // 3*50 + 1*200
        assertEquals(1, report.saleCount)
        assertEquals(7, report.chartPoints.size)
        assertEquals("ዘይት", report.topItems.first().name)
    }

    @Test
    fun backupCodec_roundTripsCreditsAndBarcode() {
        val item = Item(id = "i1", name = "Soap", barcode = "6291003012345", qty = 5)
        val credit = CustomerCredit(id = "cr1", customerName = "Kebede", totalOwedEtb = 500.0, paidEtb = 200.0)
        val json = JsonCodec.encodeBackup(listOf(item), AppSettings(), emptyList(), listOf(credit))
        val decoded = JsonCodec.decodeBackup(json)

        assertNotNull(decoded)
        assertEquals("6291003012345", decoded!!.items.first().barcode)
        assertEquals(1, decoded.credits.size)
        assertEquals(300.0, decoded.credits.first().remainingEtb, 0.01)
    }
}
