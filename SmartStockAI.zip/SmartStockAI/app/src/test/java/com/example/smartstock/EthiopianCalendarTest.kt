package com.example.smartstock

import com.example.smartstock.util.EthiopianCalendar
import com.example.smartstock.util.EthiopianDate
import com.example.smartstock.util.Formatters
import org.junit.Assert.assertEquals
import org.junit.Test
import java.time.LocalDate

class EthiopianCalendarTest {

    @Test
    fun fromGregorian_convertsNewYearAndLeapPagumeCorrectly() {
        // 2024-09-11 is Meskerem 1, 2017 (Enkutatash)
        assertEquals(EthiopianDate(2017, 1, 1), EthiopianCalendar.fromGregorian(2024, 9, 11))

        // 2023-09-11 is Pagume 6, 2015 (Ethiopian leap year 2015)
        assertEquals(EthiopianDate(2015, 13, 6), EthiopianCalendar.fromGregorian(2023, 9, 11))

        // 2023-09-12 is Meskerem 1, 2016
        assertEquals(EthiopianDate(2016, 1, 1), EthiopianCalendar.fromGregorian(2023, 9, 12))
    }

    @Test
    fun formatDate_supportsEthiopianAndGregorianStyles() {
        val date = LocalDate.of(2024, 9, 11)
        assertEquals("መስከረም 1፣ 2017", EthiopianCalendar.formatDate(date, useEthiopian = true))
        assertEquals("2024-09-11", EthiopianCalendar.formatDate(date, useEthiopian = false))
    }

    @Test
    fun formatMoney_formatsWithThousandsSeparators() {
        assertEquals("1,550", Formatters.formatMoney(1550.0))
        assertEquals("12,345.5", Formatters.formatMoney(12345.5))
        assertEquals("0", Formatters.formatMoney(0.0))
    }
}
