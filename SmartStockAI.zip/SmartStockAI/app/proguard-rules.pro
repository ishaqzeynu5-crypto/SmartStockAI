# Keep data models and org.json serialization intact
-keep class com.example.smartstock.data.** { *; }
-keep class com.example.smartstock.domain.** { *; }
-keep class com.example.smartstock.ai.** { *; }
