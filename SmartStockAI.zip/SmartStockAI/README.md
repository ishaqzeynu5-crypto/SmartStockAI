# ስማርትስቶክ ኤአይ v2.0 (SmartStock AI v2.0)

## አማርኛ — አጠቃላይ መግለጫ እና የግንባታ መመሪያ

**ስማርትስቶክ ኤአይ v2.0** ለአነስተኛ የኢትዮጵያ ሱቆች የተዘጋጀ ከመስመር ውጭ (offline-first) የመጋዘን እና የሽያጭ ረዳት የአንድሮይድ መተግበሪያ ነው። ሙሉ በሙሉ በአማርኛ ቋንቋ ይሰራል።

### ዋና ዋና ባህሪያት
- **መነሻ (Dashboard):** የዕለቱ ሽያጭ፣ የትርፍ ግምት፣ ሊያልቁ የተቃረቡ እቃዎች፣ የ7 ቀን የሽያጭ ግራፍ (Canvas)፣ የሳምንቱ 3 ከፍተኛ ሽያጮች እና በኤአይ የሚዘጋጅ **የሳምንቱ ምክር**።
- **መጋዘን (Stock):** የእቃዎች ዝርዝር፣ ፍለጋ (በስምና በተለዋጭ ስም)፣ ሊያልቁ የተቃረቡ ማጣሪያ፣ `+`/`−` ፈጣን ማስተካከያ እና **የትዕዛዝ ዝርዝር አጋራ** (Telegram/SMS)።
- **እቃ መቀበያ (Cargo):** የተላከ እና የተቀበሉትን ጭነት በካሜራ ወይም ከጋለሪ በማስገባት በጀሚኒ ኤአይ ማስቆጠር፣ በKotlin የሚሰላ የልዩነት ሰንጠረዥ (`ጎደለ`/`ተጨማሪ`/`✓`)፣ ቅድመ-ዕይታ ማስተካከያ እና ሪፖርት ማጋራት።
- **ሽያጭ (Sales):** እስከ 3 የሽያጭ ደብተር ገጾችን ፎቶ በማንሳት ሽያጩን ማንበብ፣ የማስጠንቀቂያ ምልክቶች (ከመጋዘን በላይ፣ ከ20% በላይ የዋጋ ልዩነት፣ የስሌት ልዩነት፣ ተደጋጋሚ ፎቶ) እና ከመጋዘን መቀነስ።
- **ታሪክ (History):** በቀን የተደራጀ የግብይት ታሪክ (በኢትዮጵያ ወይም ግሪጎሪያን ቀን)፣ የማስረጃ ፎቶዎች፣ **ግብይቱን ሻር (Void)** እና **CSV አውጣ** (UTF-8 BOM ለExcel)።
- **ቅንብሮች (Settings):** በAndroid Keystore (AES-256-GCM) የተቆለፈ የGemini ኤፒአይ ቁልፍ፣ የሞዴል ራስ-ሰር ምርጫ፣ ምትኬ አስቀምጥ/መልስ (JSON) እና የግላዊነት ማሳሰቢያ።

### የGemini ኤፒአይ ቁልፍ ማግኛ
1. ወደ **Google AI Studio** ይግቡ እና ነፃ የGemini API ቁልፍ ይፍጠሩ።
2. በመተግበሪያው ውስጥ **ቅንብሮች (⚙️)** ይክፈቱ፣ ቁልፉን ያስገቡ እና **አስቀምጥ** → **ቁልፉን ሞክር** ይጫኑ።

### በGitHub Actions APK መገንባት
1. ይህንን ፕሮጀክት ወደ GitHub ሪፖዚቶሪ ይጫኑ (push ያድርጉ)።
2. `.github/workflows/build.yml` በራስ-ሰር JDK 17 እና Gradle 8.9 በመጠቀም `gradle testDebugUnitTest --no-daemon` እና `gradle assembleDebug --no-daemon --stacktrace` ያስኬዳል።
3. ግንባታው አረንጓዴ ✓ ሲሆን ከ **Actions → Artifacts** ውስጥ `SmartStock-debug-apk` ያውርዱ።

---

## English — Overview & Build Instructions

**SmartStock AI v2.0** is an offline-first Android inventory and sales assistant for small Ethiopian shops with a 100% Amharic UI.

### Technical Stack (Pinned Versions)
- **Package:** `com.example.smartstock` (`versionName 2.0.0`, `versionCode 2`)
- **SDK:** `compileSdk 34`, `minSdk 26`, `targetSdk 34`, Java/Kotlin 17
- **Build & Libraries:** Gradle 8.9, AGP 8.5.2, Kotlin 1.9.24, Compose Compiler 1.5.14, Compose BOM 2024.09.00, `activity-compose 1.9.2`, `lifecycle-viewmodel-compose` & `lifecycle-runtime-compose 2.8.6`, `core-ktx 1.13.1`, `exifinterface 1.3.7`, `OkHttp 4.12.0`, `kotlinx-coroutines-android 1.8.1`, `JUnit 4.13.2`, `org.json`.
- **No forbidden dependencies:** Zero Room, KSP, kapt, Hilt, Navigation-Compose, Retrofit, Gson/Moshi, `material-icons-extended`, or third-party chart libraries.

### Build Locally
Ensure **JDK 17** and **Gradle 8.9** (with Android SDK 34 installed) are available on your machine:

```bash
gradle testDebugUnitTest --no-daemon
gradle assembleDebug --no-daemon --stacktrace
```

The debug APK is generated at `app/build/outputs/apk/debug/app-debug.apk`.

### Build on GitHub Actions
Push this repository to GitHub. The workflow in `.github/workflows/build.yml` runs on `push`, `pull_request`, and `workflow_dispatch`, executes all JUnit unit tests, builds the debug APK, and uploads it as the `SmartStock-debug-apk` artifact.
